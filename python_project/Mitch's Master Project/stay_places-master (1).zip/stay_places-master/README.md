# stay_places
